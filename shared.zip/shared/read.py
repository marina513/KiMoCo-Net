import h5py
import numpy as np
import torch
import pydicom

def read_fn(path):
    if('.h5' in path):
        data = {}
        with h5py.File(path, 'r') as f:
           
            for k in list(f.keys()):
                datak = f.get(k)
                data[k] = np.array(datak)

        return data
    elif('.dcm' in path):
        return pydicom.dcmread(path).pixel_array




def real_2_complex_shape(arr):
    if(len(arr.shape)==4 and arr.shape[1]==2):
        k_out2 = arr[:,0:1,:,:] + 1j* arr[:,1:2,:,:]
    if(len(arr.shape)==3 and arr.shape[0]==2):
        k_out2 = arr[0:1,:,:] + 1j* arr[1:2,:,:]

    return k_out2
        



def rss_comp(data: torch.Tensor, dim: int = 0) -> torch.Tensor:
    """
    Compute the Root Sum of Squares (RSS) for complex inputs.

    RSS is computed assuming that dim is the coil dimension.

    Args:
        data: The input tensor
        dim: The dimensions along which to apply the RSS transform

    Returns:
        The RSS value.
    """
    rss_real = torch.sqrt((data.real**2).sum(dim))
    rss_imag = torch.sqrt((data.imag**2).sum(dim))
    return rss_real + 1j * rss_imag
#image_rss_comp = rss_comp(image_gt, dim=1)
